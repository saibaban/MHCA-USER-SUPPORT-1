export class User {

    
        "dateOfBirth"= "";
        "email"= "";
        "firstName"= "";
        "gender"= "";
        "lastName"= "";
        "phone"= "";
        "mfaChoice"="";
        "zipCode"= "";
        "username"="";
        "password"="";
      
}
