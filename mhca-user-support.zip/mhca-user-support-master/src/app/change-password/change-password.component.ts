import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ApplicationService } from '../service/application.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  inputs:any={}
  errorMessage="";
  clientId = environment.clientId;
  secretKey = environment.secretKey;

  constructor(private applicationService:ApplicationService,private router:Router) { }

  ngOnInit(): void {
    this.applicationService.generateToken({clientId:this.clientId,secretKey:this.secretKey})
    .subscribe(data => this.applicationService.token=data.jwt);
  }

  doChangePassword(){
    this.applicationService.changePassword(this.inputs).subscribe(data =>{
      this.router.navigate(["cp-success"]);
    },error => {
      this.errorMessage = error.error.data;
    })
  }

  validate(){
    return !!this.inputs.oldPassword && 
    !!this.inputs.newPassword &&
    this.inputs.newPassword === this.inputs.confirmPassword &&
    !!this.inputs.username;
  }

  doReset(){
    this.inputs.oldPassword = "";
    this.inputs.newPassword = "";
    this.inputs.confirmPassword = "";
    this.inputs.username = "";
  }
}
