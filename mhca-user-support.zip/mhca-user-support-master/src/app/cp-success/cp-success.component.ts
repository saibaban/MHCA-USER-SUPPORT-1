import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cp-success',
  templateUrl: './cp-success.component.html',
  styleUrls: ['./cp-success.component.css']
})
export class CpSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
