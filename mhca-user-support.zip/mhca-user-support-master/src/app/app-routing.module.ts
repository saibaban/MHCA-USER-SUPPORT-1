import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { CpSuccessComponent } from './cp-success/cp-success.component';
import { RegisterPatientComponent } from './register-patient/register-patient.component';
import { RegisterSuccessComponent } from './register-success/register-success.component';

const routes: Routes = [
  { path: '', component: RegisterPatientComponent },
  { path: 'register', component: RegisterPatientComponent },
  { path: 'register-success', component: RegisterSuccessComponent },
  { path: 'cp-success', component: CpSuccessComponent },
  { path: 'change-password', component: ChangePasswordComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
