export const environment = {
  production: true,
  clientId: "client_ida1b2c3d45",
  secretKey: "123456",
  mhcaHome:"https://test.myhomecare.vnsny.org",
  baseUrl:"https://appstest.vnsny.org/vns-auth"
};
