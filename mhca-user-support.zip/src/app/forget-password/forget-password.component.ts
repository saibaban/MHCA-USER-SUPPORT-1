import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ApplicationService } from '../service/application.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent implements OnInit {

  inputs:any={}
  errorMessage="";
  sessionData:any;
  device:any;
  username:string="";
  clientId = environment.clientId;
  secretKey = environment.secretKey;

  constructor(private applicationService:ApplicationService,private router:Router) { }

  ngOnInit(): void {
    this.applicationService.generateToken({clientId:this.clientId,secretKey:this.secretKey})
    .subscribe(data => this.applicationService.token=data.jwt);
  }

  forgetPassword(){
    this.applicationService.forgetPassword(this.username).subscribe(data =>{
      this.sessionData = data.sessionData;
      this.device = data.data;
    },error => {
      this.errorMessage = error.error.data;
    })
  }


  validate(){
    return !!this.inputs.oldPassword && 
    !!this.inputs.newPassword &&
    !!this.inputs.recoveryCode &&
    this.inputs.newPassword === this.inputs.confirmPassword &&
    !!this.username; 
  }

  doReset(){
    this.inputs.recoveryCode = "";
    this.inputs.newPassword = "";
    this.inputs.confirmPassword = "";
    this.username = "";
    this.sessionData = null;
    this.device = null;
  }
  sendRecoveryCode(){
    var sendRecoveryCodeRequest = {
      sessionData:this.sessionData,
      "newPassword": this.inputs.newPassword,
      "recoveryCode":  this.inputs.recoveryCode

    }
    this.applicationService.sendRecoveryCode(sendRecoveryCodeRequest).subscribe(data =>{
      this.sessionData =null;
      this.device =null;
      this.router.navigate(["cp-success"]);
    },error => {
      this.errorMessage = error.error.data;
    })
  }
}
