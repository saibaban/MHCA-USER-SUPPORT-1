import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CpSuccessComponent } from './cp-success.component';

describe('CpSuccessComponent', () => {
  let component: CpSuccessComponent;
  let fixture: ComponentFixture<CpSuccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CpSuccessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CpSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
