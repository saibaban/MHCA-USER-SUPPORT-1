
import { HttpClient, HttpClientModule, HttpHeaders, HttpParamsOptions } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ResponseModel } from '../models/response-model';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {

  public token: string = "";

  get options() {
    return {
      headers: new HttpHeaders({
        "Authorization": "Bearer " + this.token
      })
    };
  }
  checkUsernameAvailability(value: string) {
    return this.httpClient.get<ResponseModel>(this.baseUrl + "/user/checkAvailability/" + value, this.options);
  }

  baseUrl = environment.baseUrl;
  constructor(private httpClient: HttpClient) { }


  generateToken(data: any) {
    return this.httpClient.post<any>(this.baseUrl + "/generateBearerToken", data);
  }

  register(user: User) {
    return this.httpClient.post<any>(this.baseUrl + "/register", user, this.options);
  }
  
  changePassword(data:any){
    return this.httpClient.post<any>(this.baseUrl + "/user/changePassword", data, this.options);
  }

  checkOtp(data:any){
    return this.httpClient.post<any>(this.baseUrl + "/user/checkOtp", data, this.options);
  }
  forgetPassword(username:string){
    return this.httpClient.get<any>(this.baseUrl + "/user/forgetPassword?username="+username,  this.options);
  }
  sendRecoveryCode(sendRecoveryCodeRequest:any){
    return this.httpClient.post<any>(this.baseUrl + "/user/sendRecoveryCode", sendRecoveryCodeRequest, this.options);
  }
}
