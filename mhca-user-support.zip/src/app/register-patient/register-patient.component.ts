import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { ResponseModel } from '../models/response-model';
import { User } from '../models/user';
import { ApplicationService } from '../service/application.service';

@Component({
  selector: 'app-register-patient',
  templateUrl: './register-patient.component.html',
  styleUrls: ['./register-patient.component.css']
})
export class RegisterPatientComponent implements OnInit {

  user: User = new User;
  userForm: FormGroup;


  clientId = environment.clientId;
  page = 'registration';
  ssessionData: any;
  otp: any = "";
  secretKey = environment.secretKey;
  errorMessage!: string;
  availability!: ResponseModel | undefined;
  isTermsAccepted = false;



  constructor(private applicationService: ApplicationService, private fb: FormBuilder, private router: Router) {
    this.userForm = this.fb.group({
      firstName: ['', [Validators.required, Validators.maxLength(50)]],
      lastName: ['', [Validators.required, Validators.maxLength(50)]],
      dateOfBirth: ['', Validators.required],
      gender: [''],
      mfaChoice: ['Email', Validators.required],
      email: ['', [Validators.required, Validators.pattern('[^ @]*@[^ @]*.[^ @]*')]],
      zipCode: ['', [Validators.required, Validators.pattern('[0-9]{5}'), Validators.maxLength(5), Validators.minLength(5)]],
      phone: ['', [Validators.required, Validators.pattern('[0-9]{10}')]],
      username: ['', [Validators.required, Validators.maxLength(50)]],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });
  }


  get firstName() {
    return this.userForm.get('firstName');
  }
  get lastName() {
    return this.userForm.get('lastName');
  }
  get dateOfBirth() {
    return this.userForm.get('dateOfBirth');
  }
  get gender() {
    return this.userForm.get('gender');
  }
  get mfaChoice() {
    return this.userForm.get('mfaChoice');
  }
  get email() {
    return this.userForm.get('email');
  }
  get zipCode() {
    return this.userForm.get('zipCode');
  }
  get phone() {
    return this.userForm.get('phone');
  }
  get username() {
    return this.userForm.get('username');
  }
  get password() {
    return this.userForm.get('password');
  }
  get confirmPassword() {
    return this.userForm.get('confirmPassword');
  }




  ngOnInit(): void {
    this.applicationService.generateToken({ clientId: this.clientId, secretKey: this.secretKey })
      .subscribe(data => this.applicationService.token = data.jwt);
      

  }


  validate() {
    return this.userForm.valid && this.isTermsAccepted &&
      this.password?.value === this.confirmPassword?.value && this.availability?.data;
  }

  doRegister() {

   
      let user: User = {
        dateOfBirth: this.dateOfBirth?.value,
        email: this.email?.value,
        firstName: this.firstName?.value,
        gender: this.gender?.value,
        mfaChoice: this.mfaChoice?.value,
        lastName: this.lastName?.value,
        phone: this.phone?.value,
        zipCode: this.zipCode?.value,
        username: this.username?.value,
        password: this.password?.value
      }
      this.applicationService.register(user).subscribe(data => {
        this.ssessionData = data.sessionData;
        this.doReset();
        this.page = 'otp_check';
      }, error => {
        console.log(error.error.data);
        this.errorMessage = error.error.data;
      })
    


  }

  checkUsernameAvailability() {
    this.applicationService.checkUsernameAvailability(this.username?.value)
      .subscribe(data => this.availability = data);
  }

  errorMessages() {
    return this.errorMessage.split("\r\n");
  }

  doReset() {
    this.userForm.reset();
    this.errorMessage = "";
    this.otp = "";
    this.availability = undefined;
  }

  doCheckOtp() {

    var otpRequestObject = {
      "otp": this.otp,
      "sessionData":this.ssessionData
    }
    this.applicationService.checkOtp(otpRequestObject).subscribe(data => {
      this.doReset();
      this.router.navigate(["register-success"]);
    }, error => {
      console.log(error.error.data);
      this.errorMessage = error.error.data;
    });

  }
}
