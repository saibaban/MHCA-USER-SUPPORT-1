import { Component } from '@angular/core';
import { environment } from 'src/environments/environment';
import { ApplicationService } from './service/application.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'mhca-user-support';
}
