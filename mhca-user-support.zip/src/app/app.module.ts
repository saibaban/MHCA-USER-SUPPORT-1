import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { PasswordStrengthMeterModule } from 'angular-password-strength-meter';
import { NgxMaskModule } from 'ngx-mask';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { RegisterPatientComponent } from './register-patient/register-patient.component';
import { RegisterSuccessComponent } from './register-success/register-success.component';
import { CpSuccessComponent } from './cp-success/cp-success.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterPatientComponent,
    ChangePasswordComponent,
    RegisterSuccessComponent,
    CpSuccessComponent,
    ForgetPasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
    , ReactiveFormsModule
    , FormsModule
    , HttpClientModule
    , PasswordStrengthMeterModule
    , NgxMaskModule.forRoot(),
  ],
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  bootstrap: [AppComponent]
})
export class AppModule { }
